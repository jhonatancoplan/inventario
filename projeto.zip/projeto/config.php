<?php
define('USUARIO', 'link');
define('SENHA', 'triforce');
?>
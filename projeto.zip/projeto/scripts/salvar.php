<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}

if (isset($_POST['nome']) && isset($_POST['quantidade'])) {
    $nome = trim($_POST['nome']);
    $quantidade = trim($_POST['quantidade']);
    $imagem = ""; // Inicializando a variável da imagem

    // Verifica se a opção de imagem foi marcada
    if (isset($_POST['imagem-opcao']) && $_POST['imagem-opcao'] == 'on') {
        // Usar o link da imagem fornecido
        if (isset($_POST['imagem-url']) && !empty($_POST['imagem-url'])) {
            $imagem = trim($_POST['imagem-url']);
        }
    }

    // Verifica se o nome e a quantidade são válidos
    if (!empty($nome) && is_numeric($quantidade) && $quantidade > 0) {
        // Abre o arquivo para adicionar os dados
        $arquivo = fopen("../inventario.txt", "a");
        fwrite($arquivo, "$nome|$quantidade|$imagem\n"); // Salva o nome, quantidade e a URL da imagem
        fclose($arquivo);
    }
}

header("Location: inventario.php");
?>
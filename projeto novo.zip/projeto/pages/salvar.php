<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../scripts/conexao.php"; // Inclui a conexão

if (isset($_POST['nome'], $_POST['quantidade'])) {
    $nome = trim($_POST['nome']);
    $quantidade = (int) trim($_POST['quantidade']);
    $descricao = isset($_POST['descricao']) ? trim($_POST['descricao']) : "";
    $imagem = "";

    if (isset($_POST['imagem-opcao']) && $_POST['imagem-opcao'] == 'on') {
        if (!empty($_POST['imagem-url'])) {
            $imagem = trim($_POST['imagem-url']);
        }
    }

    if (!empty($nome) && $quantidade > 0) {
        $stmt = $conn->prepare("INSERT INTO inventario (nome_item, qtd_item, descricao_item, img_item) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("siss", $nome, $quantidade, $descricao, $imagem);
        $stmt->execute();
        $stmt->close();
    }
}

$conn->close();
header("Location: inventario.php");
?>
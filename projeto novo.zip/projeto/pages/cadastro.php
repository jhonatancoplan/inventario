<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Item - Inventário</title>
    <!-- CDN Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Quicksand', sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
        }
        .btn-custom {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 30px;
            padding: 10px 20px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .btn-custom:hover {
            background-color: #45a049;
        }
        .img-options {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Cadastrar Novo Item</h2>
        <form id="form-item" action="salvar.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome do Item:</label>
                <input type="text" name="nome" class="form-control" id="nome" required>
            </div>
            <div class="mb-3">
                <label for="quantidade" class="form-label">Quantidade:</label>
                <input type="number" name="quantidade" class="form-control" id="quantidade" required>
            </div>

            <div class="mb-3">
                <label for="descricao" class="form-label">Descrição:</label>
                <textarea name="descricao" class="form-control" id="descricao" rows="3"></textarea>
            </div>

            <!-- Opção de imagem -->
            <div class="mb-3">
                <label for="imagem-opcao" class="form-label">Adicionar Imagem?</label>
                <input type="checkbox" name="imagem-opcao" id="imagem-opcao" class="form-check-input">
            </div>

            <!-- Campos de imagem (serão exibidos se a checkbox estiver marcada) -->
            <div id="img-options" class="img-options">
                <div class="mb-3">
                    <label for="imagem-url" class="form-label">insira o link da imagem:</label>
                    <input type="url" name="imagem-url" class="form-control" id="imagem-url" placeholder="http://exemplo.com/imagem.jpg">
                </div>
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-success btn-custom">Salvar</button>
                <a href="../index.php" class="btn btn-secondary btn-custom">Voltar</a>
            </div>
        </form>
    </div>

    <!-- CDN Bootstrap e Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <script>
    // Mostrar ou esconder os campos de imagem dependendo do estado da checkbox
    document.getElementById('imagem-opcao').addEventListener('change', function () {
        var imgOptions = document.getElementById('img-options');
        imgOptions.style.display = this.checked ? 'block' : 'none';
    });

    // Validação ao enviar o formulário
    document.getElementById('form-item').addEventListener('submit', function (e) {
        var imagemOpcao = document.getElementById('imagem-opcao').checked;
        var imagemURL = document.getElementById('imagem-url').value.trim();

        if (imagemOpcao && imagemURL === '') {
            alert("Por favor, insira o link da imagem.");
            e.preventDefault(); // Impede o envio
        }
    });
</script>

</body>
</html>
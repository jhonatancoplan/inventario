<?php
require_once "../scripts/conexao.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['id'];
    $nome = $_POST['nome_item'];
    $qtd = $_POST['qtd_item'];
    $descricao = $_POST['descricao_item'];
    $img = $_POST['img_item'];

    $stmt = $conn->prepare("UPDATE inventario SET nome_item=?, qtd_item=?, descricao_item=?, img_item=? WHERE id=?");
    $stmt->bind_param("sissi", $nome, $qtd, $descricao, $img, $id);

    if ($stmt->execute()) {
        header("Location: inventario.php");
        exit();
    } else {
        echo "Erro ao atualizar: " . $stmt->error;
    }
}
?>

<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header("Location: ../login.php");
    exit();
}

require_once "../scripts/conexao.php";

$sql = "SELECT * FROM inventario ORDER BY id DESC";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Inventário</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Quicksand', sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }
        .navbar {
            background-color: rgba(0, 0, 0, 0.7);
        }
        .navbar-nav .nav-link {
            color: white !important;
            font-weight: 500;
        }
        .navbar-nav .nav-link:hover {
            color: #f8f9fa !important;
        }
        .container {
            max-width: 1000px;
            margin-top: 50px;
        }
        .table th {
            background-color: #4CAF50;
            color: white;
        }
        img {
            max-width: 100px;
        }
        .edit {
            display: none;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="#">Inventário</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Voltar</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container">
    <h2 class="text-center mb-4">Inventário</h2>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>Nome</th>
            <th>Quantidade</th>
            <th>Descrição</th>
            <th>Imagem</th>
            <th>Opções</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($row = $resultado->fetch_assoc()): ?>
            <tr data-id="<?= $row['id'] ?>">
                <form method="POST" action="atualizar_item.php">
                    <td>
                        <span class="display"><?= htmlspecialchars($row['nome_item']) ?></span>
                        <input type="text" name="nome_item" class="form-control edit" value="<?= htmlspecialchars($row['nome_item']) ?>">
                    </td>
                    <td>
                        <span class="display"><?= htmlspecialchars($row['qtd_item']) ?></span>
                        <input type="number" name="qtd_item" class="form-control edit" value="<?= htmlspecialchars($row['qtd_item']) ?>">
                    </td>
                    <td>
                        <span class="display"><?= nl2br(htmlspecialchars($row['descricao_item'])) ?></span>
                        <textarea name="descricao_item" class="form-control edit"><?= htmlspecialchars($row['descricao_item']) ?></textarea>
                    </td>
                    <td>
                        <span class="display">
                            <?php if (!empty($row['img_item'])): ?>
                                <img src="<?= htmlspecialchars($row['img_item']) ?>" alt="Imagem do item">
                            <?php endif; ?>
                        </span>
                        <input type="text" name="img_item" class="form-control edit" value="<?= htmlspecialchars($row['img_item']) ?>">
                    </td>
                    <td>
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <button type="button" class="btn btn-warning btn-edit">Editar</button>
                        <button type="submit" class="btn btn-success btn-save edit">Salvar</button>
                        <a href="deletar_item.php?id=<?= $row['id'] ?>" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja deletar este item?')">Deletar</a>
                    </td>
                </form>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- JS -->
<script>
document.querySelectorAll('.btn-edit').forEach(button => {
    button.addEventListener('click', function () {
        const row = this.closest('tr');
        row.querySelectorAll('.display').forEach(el => el.style.display = 'none');
        row.querySelectorAll('.edit').forEach(el => el.style.display = 'block');
        this.style.display = 'none';
    });
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();
include '../config.php';

if ($_POST['usuario'] === USUARIO && $_POST['senha'] === SENHA) {
    $_SESSION['logado'] = true;
    header("Location: ../index.php");
} else {
    echo "<script>alert('Usuário ou senha inválidos!'); window.location.href='../login.php';</script>";
}
?>
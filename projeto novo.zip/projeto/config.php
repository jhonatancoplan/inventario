<?php
define('USUARIO', 'teste');
define('SENHA', '12345678');
?>